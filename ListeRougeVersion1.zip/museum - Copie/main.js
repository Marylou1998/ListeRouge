let currentGame;
let percentageDisplay = document.getElementById('percentage-display');  // Assurez-vous d'avoir un élément pour afficher le pourcentage

function loadGame(gameName) {
  // Remove the current game if there's one
  if (currentGame) {
    currentGame.remove();
  }

  // Load the selected mini-game
  switch (gameName) {
    case 'colorier':
      import('./colorier.js').then(module => {
        currentGame = new p5(module.default, 'sketch-container');  // Create a new p5 instance with the imported module
      }).catch(error => {
        console.error('Error loading colorier game:', error);
      });
      break;
    case 'poesie':
      import('./poesie.js').then(module => {
        currentGame = new p5(module.default, 'sketch-container');
      }).catch(error => {
        console.error('Error loading poesie game:', error);
      });
      break;
    default:
      console.error('Unknown game:', gameName);
  }
}

// Fonction qui met à jour le pourcentage affiché
function updatePercentage() {
  if (currentGame) {
    let percentage = currentGame.getCoveredPercentage();
    
    // Met à jour l'affichage dans l'élément HTML
    const percentageDisplay = document.getElementById('percentage-display');
    if (percentageDisplay) {
      percentageDisplay.innerText = percentage.toFixed(2) + '%';  // Format à 2 décimales
    }
  }
}

// Appelle la fonction d'update pour afficher le pourcentage
function draw() {
  updatePercentage();
}
