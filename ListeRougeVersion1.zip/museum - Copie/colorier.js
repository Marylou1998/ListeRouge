export default function(p) {
  let bottomImg, topImg, topLayer;
  let modifiedPixels = 0; // Compteur de pixels modifiés
  let totalPixels; // Total de pixels dans l'image
  let hasModified = []; // Tableau pour suivre les zones modifiées
  const brushSize = 20; // Taille du pinceau : trop petite ? dépend du but...

  p.preload = function() {
    bottomImg = p.loadImage('/images/lynxTOP2.jpg');  // Image de FOND
    topImg = p.loadImage('/images/lynxBOTTOM.jpeg');     // Image à gratter, donc par-dessus
  };

  p.setup = function() {
    p.createCanvas(720, 500);

    const canvasElement = p.canvas;
    canvasElement.style.border = '10px solid black';
    canvasElement.style.display = 'block';
    canvasElement.style.margin = 'auto';
    canvasElement.style.position = 'absolute';
    canvasElement.style.top = '50%';
    canvasElement.style.left = '50%';
    canvasElement.style.transform = 'translate(-50%, -50%)';


    // Placer l'image de fond en arrière-plan, pas interactive.
    p.background(bottomImg);

    // Crée une sorte de calque pour topImg et copie son contenu
    topLayer = p.createGraphics(p.width, p.height);
    topLayer.image(topImg, 0, 0);

    //suivi des pixels modifiés
    totalPixels = p.width * p.height;
    hasModified = new Array(totalPixels).fill(false);
    p.noStroke(); // Désactive le contour des formes
  };

  p.draw = function() {
    // Redessine le calque topLayer par-dessus le fond
    p.image(bottomImg, 0, 0); // Conserve le fond
    p.image(topLayer, 0, 0);  // Superpose le calque modifié
  };

  p.mouseDragged = function() {
    const x = Math.floor(p.mouseX);
    const y = Math.floor(p.mouseY);

    // Vérifie si la souris est dans les limites de la canvas
    if (x >= 0 && y >= 0 && x < p.width && y < p.height) {
      // Dessine un cercle transparent sur le calque topLayer
      topLayer.erase();
      topLayer.ellipse(x, y, brushSize, brushSize); // Efface un cercle
      topLayer.noErase();

      // Suivre les pixels modifiés dans la zone du cercle
      const radiusSquared = (brushSize / 2) ** 2;
      for (let i = Math.max(0, y - brushSize / 2); i < Math.min(p.height, y + brushSize / 2); i++) {
        for (let j = Math.max(0, x - brushSize / 2); j < Math.min(p.width, x + brushSize / 2); j++) {
          // Vérifie si le pixel est dans le cercle
          const dx = j - x;
          const dy = i - y;
          if (dx * dx + dy * dy <= radiusSquared) {
            const index = i * p.width + j;
            if (!hasModified[index]) {
              hasModified[index] = true;
              modifiedPixels++;
            }
          }
        }
      }
    }
  };

  //pourcentage de pixels modifiés
  p.getCoveredPercentage = function() {
    return (modifiedPixels / totalPixels) * 100;
  };
}
