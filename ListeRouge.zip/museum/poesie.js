export default function(p) {
    let bottomImg, topImg;
    let totalPixels; // Nombre total de pixels de l'image
    let pixelsCovered = 0; // Nombre de pixels recouverts
  
    // Preload images within the instance
    p.preload = function() {
      bottomImg = p.loadImage('/images/success1.jpg');  // Image de fond
      topImg = p.loadImage('/images/success2.jpg');     // Image à gratter
    };
  
    p.setup = function() {
      p.describe('Black-and-white photograph of a parrot. The cursor, when dragged across the canvas, adds color to the photograph.');
      p.createCanvas(720, 400);
      
      p.image(topImg, 0, 0); // Affiche l’image supérieure au départ
  
      // Calculer le nombre total de pixels dans l'image
      totalPixels = bottomImg.width * bottomImg.height;
    };
  
    p.mouseDragged = function() {
      // Copie une petite zone de l'image inférieure à la position de la souris
      p.copy(bottomImg, p.mouseX, p.mouseY, 20, 20, p.mouseX, p.mouseY, 20, 20);
  
      // Vérifier les pixels recouverts pour mettre à jour le compteur
      let imgPixels = p.get(); // Récupère les pixels du canevas complet
      for (let x = p.mouseX; x < p.mouseX + 20; x++) {
        for (let y = p.mouseY; y < p.mouseY + 20; y++) {
          let c = imgPixels.get(x, y);
          if (p.red(c) !== 0 || p.green(c) !== 0 || p.blue(c) !== 0) {
            pixelsCovered++;
          }
        }
      }
    };
  
    p.draw = function() {
      // Redessiner l'image de fond (bottomImg) en arrière-plan
      p.image(bottomImg, 0, 0);
  
      // Redessiner l'image supérieure (topImg) au-dessus de l'image de fond
      p.image(topImg, 0, 0);
    };
  
    // Exposer une fonction qui retourne le pourcentage de pixels recouverts
    p.getCoveredPercentage = function() {
      return (pixelsCovered / totalPixels) * 100;
    };
  }
  